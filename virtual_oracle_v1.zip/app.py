
import streamlit as st
import pandas as pd
import random
import math
from pathlib import Path

st.set_page_config(page_title="Virtual Oracle — My Predictor", page_icon="⚽", layout="wide")

st.title("⚽ Virtual Oracle — My Predictor")
st.caption("V1: statistical prototype. It does not claim to predict a random virtual-sports RNG.")

st.info(
    "SportyBet says its virtual football simulations use independent random-number generators "
    "and algorithms. This app therefore treats predictions as experimental probabilities, not guaranteed outcomes."
)

# -----------------------------
# Prediction engine
# -----------------------------
def normalize(v):
    v = max(0.001, v)
    return v

def predict(home, away, h2h_home=0.50, home_form=0.50, away_form=0.50,
            over_rate=0.50, draw_rate=0.25):
    # Transparent baseline model. Replace weights later with trained data.
    home_strength = (
        0.42 * h2h_home +
        0.23 * home_form +
        0.12 * (1 - away_form) +
        0.13 * (1 - draw_rate) +
        0.10 * over_rate
    )
    away_strength = (
        0.42 * (1 - h2h_home) +
        0.23 * away_form +
        0.12 * (1 - home_form) +
        0.13 * (1 - draw_rate) +
        0.10 * over_rate
    )
    draw_strength = 0.55 * draw_rate + 0.45 * (1 - abs(home_strength-away_strength))

    total = normalize(home_strength) + normalize(draw_strength) + normalize(away_strength)
    hp = normalize(home_strength) / total
    dp = normalize(draw_strength) / total
    ap = normalize(away_strength) / total

    probs = {"HOME": hp, "DRAW": dp, "AWAY": ap}
    pick = max(probs, key=probs.get)
    confidence = probs[pick]

    # Simple score estimate from win/draw probabilities.
    if pick == "HOME":
        score = "2–1" if dp > 0.24 else "2–0"
    elif pick == "AWAY":
        score = "1–2" if dp > 0.24 else "0–2"
    else:
        score = "1–1"

    return probs, pick, confidence, score

# -----------------------------
# Sidebar controls
# -----------------------------
st.sidebar.header("Model controls")
h2h = st.sidebar.slider("Home H2H share", 0.00, 1.00, 0.50, 0.01)
hf = st.sidebar.slider("Home recent-form share", 0.00, 1.00, 0.50, 0.01)
af = st.sidebar.slider("Away recent-form share", 0.00, 1.00, 0.50, 0.01)
over = st.sidebar.slider("Over-rate", 0.00, 1.00, 0.50, 0.01)
draw = st.sidebar.slider("Draw-rate", 0.00, 1.00, 0.25, 0.01)

st.sidebar.markdown("---")
st.sidebar.write("**Tip:** Start with neutral values. Only change them when your historical data supports the change.")

# -----------------------------
# Manual prediction
# -----------------------------
st.header("1. Generate a prediction")
c1, c2 = st.columns(2)
with c1:
    home = st.text_input("Home team", "Team A")
with c2:
    away = st.text_input("Away team", "Team B")

if st.button("🔮 Predict", type="primary", use_container_width=True):
    probs, pick, conf, score = predict(home, away, h2h, hf, af, over, draw)
    st.subheader(f"{home} vs {away}")

    a,b,c = st.columns(3)
    a.metric("HOME", f"{probs['HOME']*100:.1f}%")
    b.metric("DRAW", f"{probs['DRAW']*100:.1f}%")
    c.metric("AWAY", f"{probs['AWAY']*100:.1f}%")

    st.success(f"Prediction: **{pick}**  |  Confidence: **{conf*100:.1f}%**  |  Experimental score: **{score}**")

# -----------------------------
# Batch testing / backtesting
# -----------------------------
st.header("2. Backtest your model")
st.write("Upload a CSV containing historical matches. This lets you measure whether the model actually works instead of trusting marketing claims.")

template = pd.DataFrame([
    {"home":"Team A","away":"Team B","h2h_home":0.55,"home_form":0.60,"away_form":0.45,"over_rate":0.55,"draw_rate":0.25,"actual":"HOME"},
    {"home":"Team C","away":"Team D","h2h_home":0.40,"home_form":0.45,"away_form":0.60,"over_rate":0.50,"draw_rate":0.30,"actual":"AWAY"},
])
st.download_button(
    "⬇️ Download CSV template",
    template.to_csv(index=False).encode("utf-8"),
    file_name="virtual_oracle_data_template.csv",
    mime="text/csv"
)

file = st.file_uploader("Upload historical CSV", type=["csv"])
if file:
    df = pd.read_csv(file)
    required = ["home","away","h2h_home","home_form","away_form","over_rate","draw_rate","actual"]
    missing = [x for x in required if x not in df.columns]
    if missing:
        st.error("Missing columns: " + ", ".join(missing))
    else:
        rows=[]
        for _, r in df.iterrows():
            probs,pick,conf,score = predict(
                str(r.home), str(r.away), float(r.h2h_home), float(r.home_form),
                float(r.away_form), float(r.over_rate), float(r.draw_rate)
            )
            actual = str(r.actual).upper().strip()
            rows.append({
                "Home": r.home, "Away": r.away, "Prediction": pick,
                "Confidence": round(conf*100,1), "Score": score, "Actual": actual,
                "Correct": pick == actual
            })
        out = pd.DataFrame(rows)
        accuracy = out["Correct"].mean() * 100 if len(out) else 0
        st.metric("Historical accuracy", f"{accuracy:.1f}%")
        st.dataframe(out, use_container_width=True)
        st.download_button(
            "⬇️ Download test results",
            out.to_csv(index=False).encode("utf-8"),
            file_name="virtual_oracle_backtest.csv",
            mime="text/csv"
        )

# -----------------------------
# Screenshot stage placeholder
# -----------------------------
st.header("3. Screenshot input — next stage")
st.write(
    "The next module will use OCR to read a SportyBet screenshot and turn detected matches into rows "
    "for this prediction engine."
)
img = st.file_uploader("Upload a screenshot (PNG/JPG)", type=["png","jpg","jpeg"], key="screenshot")
if img:
    st.image(img, caption="Uploaded screenshot", use_container_width=True)
    st.warning("OCR is intentionally not enabled in V1. We will add it after confirming the screenshot layout.")
