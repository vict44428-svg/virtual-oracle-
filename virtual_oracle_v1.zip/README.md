# Virtual Oracle V1

A first working prototype for a personal virtual-sports prediction/backtesting tool.

## Run
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run:
   `pip install -r requirements.txt`
4. Run:
   `streamlit run app.py`

## What V1 does
- Manual home/draw/away prediction
- Transparent probability model
- CSV historical backtesting
- Accuracy measurement
- Screenshot upload placeholder

## Important
SportyBet describes its virtual football simulations as being created using independent random number generators and algorithms. The app therefore does not promise a way to beat the system. The purpose is to test hypotheses against data.
